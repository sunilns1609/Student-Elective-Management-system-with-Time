-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2013 at 05:05 AM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `7thsem`
--

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

CREATE TABLE IF NOT EXISTS `coordinator` (
  `cid` varchar(20) NOT NULL,
  `cname` varchar(20) DEFAULT NULL,
  `cbranch` varchar(5) DEFAULT NULL,
  `csubmit` tinyint(1) DEFAULT NULL,
  `cuser_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `ecuser_id` (`cuser_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `coordinator`
--

INSERT INTO `coordinator` (`cid`, `cname`, `cbranch`, `csubmit`, `cuser_id`) VALUES
('ec1', 'Administrator', 'CSE', 0, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `elective_subject`
--

CREATE TABLE IF NOT EXISTS `elective_subject` (
  `ecode` varchar(10) NOT NULL,
  `ename` varchar(45) DEFAULT NULL,
  `credits` varchar(11) DEFAULT NULL,
  `esem` int(11) DEFAULT NULL,
  `no_of_classes` varchar(11) DEFAULT NULL,
  `no_of_students` int(11) DEFAULT NULL,
  `egroup` char(1) DEFAULT NULL,
  `max_per_class` varchar(11) NOT NULL,
  `etime` varchar(40) NOT NULL,
  `ebranch` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`ecode`),
  UNIQUE KEY `Ename_UNIQUE` (`ename`),
  UNIQUE KEY `Etime_UNIQUE` (`etime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `elective_subject`
--

INSERT INTO `elective_subject` (`ecode`, `ename`, `credits`, `esem`, `no_of_classes`, `no_of_students`, `egroup`, `max_per_class`, `etime`, `ebranch`) VALUES
('CSPE717', 'Service Oriented Architechture', '100', 6, '1', 0, 'a', '85', 'mon(7-8)&wed(9-10)', 'CSE'),
('CSPE718', 'Storage Area Networks', '100', 6, '1', 0, 'a', '85', 'tue(11-120)&thu(3-4)', 'CSE'),
('CSPE730', 'Parallel Programming using CUDA', '100', 6, '1', 0, 'b', '30', 'thu(7-8)&sat(8-9)', 'CSE'),
('CSPE731', 'Cloud Computing', '100', 6, '2', 0, 'b', '70', 'mon(8-9)&thu(4-5)', 'CSE'),
('ISPE717', 'Operating system', '100', 6, '1', 0, 'a', '85', 'thu(7-8)&wed(9-10)', 'ISE'),
('ISPE718', 'Advance Java', '100', 6, '1', 0, 'a', '85', 'wed(11-120)&thu(3-4)', 'ISE'),
('ISPE730', 'Pearl programming', '100', 6, '1', 0, 'b', '30', 'fri(7-8)&sat(8-9)', 'ISE'),
('ISPE731', 'Real time operating system', '100', 6, '2', 0, 'b', '70', 'sat(8-9)&thu(4-5)', 'ISE'),
('ECPE717', 'Analog mixed signal design', '100', 6, '1', 0, 'a', '85', 'tue(7-8)&wed(9-10)', 'ECE'),
('ECPE718', 'ARM processor', '100', 6, '1', 0, 'a', '85', 'mon(11-120)&thu(3-4)', 'ECE'),
('ECPE730', 'Advance VLSI design', '100', 6, '1', 0, 'b', '30', 'wed(7-8)&sat(8-9)', 'ECE'),
('ECPE731', 'Embedded system design', '100', 6, '2', 0, 'b', '70', 'fri(8-9)&thu(4-5)', 'ECE');

-- --------------------------------------------------------

--
-- Table structure for table `group_a`
--

CREATE TABLE IF NOT EXISTS `group_a` (
  `gausn` varchar(40) NOT NULL,
  `1st_pref` varchar(45) DEFAULT NULL,
  `2nd_pref` varchar(45) DEFAULT NULL,
  `FCFS` int(11) NOT NULL,
  `time_pref_1` varchar(45) DEFAULT NULL,
  `time_pref_2` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`gausn`),
  KEY `1st_fka` (`1st_pref`),
  KEY `2nd_fka` (`2nd_pref`),
  KEY `time1_fka` (`time_pref_1`),
  KEY `time2_fka` (`time_pref_2`),
  KEY `GAusn` (`gausn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `group_b`
--

CREATE TABLE IF NOT EXISTS `group_b` (
  `gbusn` varchar(40) NOT NULL,
  `1st_pref` varchar(45) DEFAULT NULL,
  `2nd_pref` varchar(45) DEFAULT NULL,
  `FCFS` int(11) NOT NULL,
  `time_pref_1` varchar(45) DEFAULT NULL,
  `time_pref_2` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`gbusn`),
  KEY `1st_fkb` (`1st_pref`),
  KEY `2nd_fkb` (`2nd_pref`),
  KEY `time1_fkb` (`time_pref_1`),
  KEY `time2_fkb` (`time_pref_2`),
  KEY `GBusn` (`gbusn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `user_id` varchar(20) NOT NULL,
  `password` varchar(10) DEFAULT NULL,
  `type_of_user` varchar(20) DEFAULT NULL,
  `Branch` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `password`, `type_of_user`, `Branch`) VALUES
('1AY15IS001', 'is001', 'student', 'ISE'),
('1AY15IS002', 'is002', 'student', 'ISE'),
('1AY15IS003', 'is003', 'student', 'ISE'),
('1AY15IS004', 'is004', 'student', 'ISE'),
('1AY15IS005', 'is005', 'student', 'ISE'),
('1AY15CS001', 'cs001', 'student', 'CSE'),
('1AY15CS002', 'cs002', 'student', 'CSE'),
('1AY15CS003', 'cs003', 'student', 'CSE'),
('1AY15CS004', 'cs004', 'student', 'CSE'),
('1AY15CS005', 'cs005', 'student', 'CSE'),
('1AY15EC001', 'ec001', 'student', 'ECE'),
('1AY15EC002', 'ec002', 'student', 'ECE'),
('1AY15EC003', 'ec003', 'student', 'ECE'),
('1AY15EC004', 'ec004', 'student', 'ECE'),
('1AY15EC005', 'ec005', 'student', 'ECE'),
('1AY15IS027', 'is027', 'student', 'ISE'),
('bhavana', 'bhavana', 'coordinator', 'ISE'),
('admin', 'ecadmin', 'coordinator', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `usn` varchar(20) NOT NULL,
  `sfname` varchar(20) DEFAULT NULL,
  `sminit` varchar(6) DEFAULT NULL,
  `slname` varchar(20) DEFAULT NULL,
  `sbranch` varchar(10) DEFAULT NULL,
  `ssem` int(11) DEFAULT NULL,
  `sec` char(1) DEFAULT NULL,
  `group_A` varchar(50) DEFAULT NULL,
  `group_B` varchar(50) DEFAULT NULL,
  `group_T1` varchar(50) DEFAULT NULL,
  `group_T2` varchar(50) DEFAULT NULL,
  `suser_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`usn`),
  KEY `user_id` (`suser_id`),
  KEY `ti2` (`group_T2`),
  KEY `ti1` (`group_T1`),
  KEY `s1` (`group_A`),
  KEY `s2` (`group_B`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`usn`, `sfname`, `sminit`, `slname`, `sbranch`, `ssem`, `sec`, `group_A`, `group_B`, `group_T1`, `group_T2`, `suser_id`) VALUES
('1AY15IS001', 'AAKASH ', NULL, 'PATHAK', 'ISE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15IS001'),
('1AY15IS002', 'AANCHAL ', NULL, 'JAIN', 'ISE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15IS002'),
('1AY15IS003', 'ABDUL ', 'P', 'RASIQ ', 'ISE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15IS003'),
('1AY15IS004', 'ABHISHEK ', 'B K', NULL, 'ISE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15IS004'),
('1AY15IS005', 'ABHISHEK', NULL, ' KUMAR', 'ISE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15IS005'),
('1AY15CS001', 'AAKH ', NULL, 'PATHAK', 'CSE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15CS001'),
('1AY15CS002', 'ACHAL ', NULL, 'JAIN', 'CSE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15CS002'),
('1AY15CS003', 'DUL ', 'P', 'RASIQ ', 'CSE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15CS003'),
('1AY15CS004', 'HISHEK ', 'B K', NULL, 'CSE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15CS004'),
('1AY15CS005', 'HISHEK', NULL, ' KUMAR', 'CSE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15CS005'),
('1AY15EC001', 'AAKH ', NULL, 'PATHAK', 'ECE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15EC001'),
('1AY15EC002', 'AANCL ', NULL, 'JAIN', 'ECE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15EC002'),
('1AY15EC003', 'ABL ', 'P', 'RASIQ ', 'ECE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15EC003'),
('1AY15EC004', 'ABHISK ', 'B K', NULL, 'ECE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15EC004'),
('1AY15EC005', 'ABHISK', NULL, ' KUMAR', 'ECE', 7, 'A', NULL, NULL, NULL, NULL, '1AY15EC005'),
('1AY15IS027', 'Bhavana', NULL, 'S', 'ISE', 6, 'A', NULL, NULL, NULL, NULL, '1AY15IS027');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE IF NOT EXISTS `teacher` (
  `sl_no` int(11) NOT NULL DEFAULT '0',
  `tname` varchar(45) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
   PRIMARY KEY (`sl_no`),
  KEY `t1` (`subject`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`sl_no`, `tname`, `subject`, `Department`) VALUES
(1, 'Dr. K G Srinivasa', 'Parallel Programming using CUDA', 'CSE'),
(2, 'Malle Gowda M', 'Service Oriented Architechture', 'CSE'),
(3, 'H V Divakar', 'Storage Area Networks', 'CSE'),
(4, 'Rajarajeshwari', 'Cloud Computing', 'CSE'),
(5, 'Sumanth ', 'Analog mixed signal design', 'ISE'),
(6, 'Bhavana S', 'Operating system', 'ISE'),
(7, 'Kiran ', 'Advance Java', 'ISE'),
(8, 'Vishal', 'Pearl programming', 'ISE'),
(9, 'Saritha', 'ARM processor', 'ECE'),
(10, 'Sunil ', 'Advance VLSI design', 'ECE'),
(11, 'Poorvika ', 'Real time operating system', 'ISE'),
(12, 'Anand ', 'Embedded system design', 'ECE');
--
-- Constraints for dumped tables
--

--
-- Constraints for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD CONSTRAINT `ecuser_id` FOREIGN KEY (`cuser_id`) REFERENCES `login` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
--
--
-- Constraints to eletives
-- ALTER TABLE `elective_subject`
-- ADD CONSTRAINT ``


--
-- Constraints for table `group_a`
--
ALTER TABLE `group_a`
  ADD CONSTRAINT `GAusn` FOREIGN KEY (`gausn`) REFERENCES `student` (`usn`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `group_a_ibfk_1` FOREIGN KEY (`1st_pref`) REFERENCES `elective_subject` (`ename`),
  ADD CONSTRAINT `group_a_ibfk_2` FOREIGN KEY (`2nd_pref`) REFERENCES `elective_subject` (`ename`),
  ADD CONSTRAINT `group_a_ibfk_t1` FOREIGN KEY (`time_pref_1`) REFERENCES `elective_subject` (`etime`),
  ADD CONSTRAINT `group_a_ibfk_t2` FOREIGN KEY (`time_pref_2`) REFERENCES `elective_subject` (`etime`);

--
-- Constraints for table `group_b`
--
ALTER TABLE `group_b`
  ADD CONSTRAINT `GBusn` FOREIGN KEY (`gbusn`) REFERENCES `student` (`usn`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `group_b_ibfk_1` FOREIGN KEY (`1st_pref`) REFERENCES `elective_subject` (`ename`),
  ADD CONSTRAINT `group_b_ibfk_2` FOREIGN KEY (`2nd_pref`) REFERENCES `elective_subject` (`ename`),
  ADD CONSTRAINT `group_b_ibfk_t1` FOREIGN KEY (`time_pref_1`) REFERENCES `elective_subject` (`etime`),
  ADD CONSTRAINT `group_b_ibfk_t2` FOREIGN KEY (`time_pref_2`) REFERENCES `elective_subject` (`etime`);
--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`suser_id`) REFERENCES `login` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `s1` FOREIGN KEY (`group_A`) REFERENCES `elective_subject` (`ename`),
  ADD CONSTRAINT `s2` FOREIGN KEY (`group_B`) REFERENCES `elective_subject` (`ename`),
  ADD CONSTRAINT `ti1` FOREIGN KEY (`group_T1`) REFERENCES `elective_subject` (`etime`),
  ADD CONSTRAINT `ti2` FOREIGN KEY (`group_T2`) REFERENCES `elective_subject` (`etime`);
--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `t1` FOREIGN KEY (`subject`) REFERENCES `elective_subject` (`ename`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

